package com.example.manalighare.mapColoring.util;

public class constants {
    public static final String MAPVIEW_BUNDLE_KEY = "MapViewBundleKey";
}
